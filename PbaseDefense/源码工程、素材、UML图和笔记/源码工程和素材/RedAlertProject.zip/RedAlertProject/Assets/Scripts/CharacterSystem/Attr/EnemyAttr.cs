﻿using System;
using System.Collections.Generic;
using System.Text;


public class EnemyAttr:ICharacterAttr
{
    public EnemyAttr(IAttrStrategy strategy,int lv, CharacterBaseAttr baseAttr) : base(strategy,lv,baseAttr) { }
}
