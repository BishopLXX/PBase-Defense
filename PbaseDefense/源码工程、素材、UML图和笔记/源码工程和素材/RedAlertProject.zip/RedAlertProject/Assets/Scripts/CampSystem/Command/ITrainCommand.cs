﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public abstract class ITrainCommand
{
    public abstract void Execute();
}
